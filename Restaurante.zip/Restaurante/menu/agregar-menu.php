<?php

				require("conectar.php");

				$nombre=$_POST['nombre'];
				$precio=$_POST['precio'];
				$tipo=$_POST['tipo'];
				$descripcion=$_POST['descripcion'];
				
				if ($nombre=="" && $precio=="") {
					echo "Usuario no agregado, por favor rellene campos requeridos correctamente";
					echo '<a title="Salir" href="inventario.php"><img src="../Images/icono-volver.png" width="200px" height="100px"></a>';
				}else{		
					$agregar="INSERT INTO menu (nombre,precio,tipo,descripcion) VALUES ('$nombre','$precio','$tipo','$descripcion')";	
					$resultado=mysqli_query($conexion,$agregar);

						if ($resultado) {
							header("location: menu.php");
					
					} else {
						echo "<br>";
						echo "Error, articulo no agregado";	
					}
				}

		?>	
