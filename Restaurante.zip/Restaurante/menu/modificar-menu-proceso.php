<?php
require("conectar.php");

$id=$_REQUEST['id'];
$nombre=$_POST['nombre'];
$precio=$_POST['precio'];
$tipo=$_POST['tipo'];
$descripcion=$_POST['descripcion'];


$modificar="UPDATE menu SET nombre='$nombre', precio='$precio' , tipo='$tipo' , descripcion='$descripcion' WHERE id ='$id' ";	
$resultado=mysqli_query($conexion,$modificar);

if ($resultado) {
	header("location: menu.php");
}else {
	echo "Error en la modificacion";
}