<html lang="es">
	<head>
		<title>Agregar a la Carta</title>
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/style2.css">
	</head>
	<body>
		
			<div class="jumbotron boxlogin">
			<h2><center>Nuevo plato</center></h2>
					
			<form action="agregar-menu.php" method="post">
			<br>
			<label>Nombre </label>
			<input type="text" placeholder="Nombre" name="nombre"  class="form-control" required="">
			<br>
			<label>Precio </label>
			<input type="text" placeholder="$" name="precio" class="form-control" required="">
			<br>
			<label>Tipo </label>
			<input type="text" placeholder="Tipo" name="tipo" class="form-control" required="">
			<br>
			<label>Descripcion </label>
			<textarea rows="4" cols="20" name="descripcion" class="form-control" required=""></textarea>			
			<br><center>
			<input type="submit" class="btn btn-primary" name="Enviar"></center>			
			<br><center>
			<input type="button" class="btn btn-success" value="Volver" onClick='document.location.href="menu.php"'></center>
			</form>
		
		</div>
		
	</body>
</html>