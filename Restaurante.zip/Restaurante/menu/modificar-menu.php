
<html lang="es">
	<head>
		<title>Modificar Menu</title>
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/style2.css">
	</head>
	<body>
		<?php

		$id=$_REQUEST['id'];
		require("conectar.php");
		$sql="SELECT * FROM menu WHERE ID='$id'";
		$consulta=$conexion->query($sql);
 		$mostrar=$consulta->fetch_assoc();
 		?> 

			<div class="jumbotron boxlogin">
			<h2><center>Modificar</center></h2>
					
			<form action="modificar-menu-proceso.php?id=<?php echo $mostrar['ID'];?>" method="post">
			<br>
			<label>Nombre </label>
			<input type="text" placeholder="Nombre" name="nombre"  class="form-control" required="" value="<?php echo $mostrar['nombre']; ?>">
			<br>
			<label>Precio </label>
			<input type="text" placeholder="Precio" name="precio" class="form-control" required="" value="<?php echo $mostrar['precio'];?>">
			<br>
			<label>Tipo </label>
			<input type="text" placeholder="Tipo" name="tipo" class="form-control" required="" value="<?php echo $mostrar['tipo']; ?>">
			<br>
			<label>Descripcion </label>
			<textarea rows="3" cols="20" name="descripcion" class="form-control" value="<?php echo $mostrar['descripcion']; ?>"></textarea>

			<!-- Botones -->
			<br><center>
			<input type="submit" class="btn btn-primary" name="Modificar" value="Modificar"></center>
			<br><center>
			<input type="button" class="btn btn-success" value="Volver" onClick='document.location.href="menu.php"'></center>		
			</form>
		
		</div>
		
	</body>
</html>