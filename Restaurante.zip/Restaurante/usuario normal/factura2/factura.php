<html>
<head>
	<meta http-equiv="Content type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
	<title>Factura</title>
	<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../assets/SweetAlert2/sweetalert2.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../assets/css/factura.css">
    
</head>
<div id="header">
	<div class="col text-right">
			<a href="#mirar" class="btn btn-primary btn-lg" data-toggle="modal"> Menu </a>
				<div class="modal fade" id="mirar">
					<div class="modal-dialog">
							<div class="modal-content">
								<div class="modal-header" style="background-color: #D5F5E3 ">
								<button tyle="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
								<h3 class="modal-title"><center><strong>Menu</strong></center></h3>
								</div>
								<div class="modal-body"><center>
								<table border="1">
								
									<tbody>
										<tr>
											<td>ID</td>
											<td>PLATO</td>
										</tr>
										<?php
											require("../../conectar.php");
											$sql='SELECT * FROM menu';
											$consulta=$conexion->query($sql);
			 								while ($mostrar=$consulta->fetch_assoc()) {
					
										echo '<tr>';
										echo '<td>';
										echo $mostrar['ID'];
										echo '</td>';
										echo '<td>';
										echo $mostrar['nombre']; 
										echo '</td>';
										echo '</tr>';
									};
										?>
										</tbody>
								</table></center>
																
								</div>
							</div>
					</div>
				</div>
	
	<input type="button" value="Salir" class="btn btn-warning btn-lg" onclick="Eventosalir()" />

       <script>
       		function Eventosalir(){
		swal("¿Seguro que desea Salir?","Al salir quedaran los valores no cobrados de la factura!", {
			  buttons: {
			    cancel: "Cancelar",
			    Salir: true,
			  },
			})
			.then((value) => {
			  switch (value) {
			 
			    case "Salir":
			    		window.location='../index2.php';
			      break;
			 
			    default:
			      swal("Cancelado","","error");
			  }
			});
       		}
		</script>
	</div>
</div>
    
<body>
		<div class="jumbotron boxfac">

		<center><form action="agregar-factura.php" method="GET" accept-charset="utf-8">
		ID MENU: 
		<input type="text" name="id-menu" placeholder="ID" required="">
		Cantidad:
		<input type="text" name="cantidad" placeholder="#" required="">	
		<input type="submit" class="btn btn-success" value="Agregar" > 
					
		</form> </center>

		</div>
<br>
<center><table border="1px">
			<thead>
				<tr>
					<th colspan="6" align="center"><center>ORDEN PEDIDO</center></th>
				</tr>
				<tr>
					<td><b><center>ID</center></td>
					<td><b><center>NOMBRE</center></td>
					<td><b><center>VALOR UNITARIO</center></td>
					<td><b><center>CANTIDAD</center></td>
					<td><b><center>TOTAL PROD</center></td>
					<td><b><center>OPERACION</center></td>
				</tr>

				</thead>
				<tbody>

		
					<?php
					require("../../conectar.php");
					$sql='SELECT * FROM pedido';
					$consulta=$conexion->query($sql);
			 		while ($mostrar=$consulta->fetch_assoc()) {
					$id_prueba=$mostrar['ID'];
					if ($id_prueba == "0") {
						 
						require("../../conectar.php");
						$eliminart= "DELETE FROM pedido WHERE ID = '$id_prueba";
						$accion=$conexion->query($eliminart);
					}else{
			 			echo '<tr>';
						echo '<td>';
						echo "<center>","<strong>";
						echo $mostrar['ID'];
						echo "</strong>","</center>";
						echo '</td>';
						echo '<td>';
						echo "<center>";
						echo $mostrar['nombre']; 
						echo "</center>";
						echo '</td>';
						echo '<td>';
						echo "<center>";
						echo $mostrar['precio'];
						echo "</center>";
						echo '</td>';
						echo '<td>';
						echo "<center>";
						echo $mostrar['cantidad'];
						echo "</center>";
						echo '</td>';
						echo '<td>';
						echo "<center>";
						echo $mostrar['subtotal'];
						echo "</center>";
						echo '</td>';

					?>

					<td><a href="eliminar-pedido.php?id=<?php echo $mostrar['ID'];?>"><center><button>Eliminar</button></center></a></td>
					
					<?php
					echo '</tr>';
					}
					};
					?>

					<tr>
						<td colspan="4">
							<center>Subtotal: </center>
						</td>
						<td colspan="2">
							<center>
							<?php 
								require("../../conectar.php");
								$sql2="SELECT SUM(subtotal) as TotalPrecios FROM pedido";
								$consulta2=$conexion->query($sql2);
								$fila=$consulta2->fetch_assoc();

								$totalprecios=$fila['TotalPrecios'];

								echo "$totalprecios";
							?>
							</center>
						</td>
						
					</tr>
					<tr>
						<td colspan="4">
							<center>Iva: </center>
						</td>
						<td colspan="2">
							<center>
							<?php 
								require("../../conectar.php");
								$sql2="SELECT SUM(subtotal) as TotalPrecios FROM pedido";
								$consulta2=$conexion->query($sql2);
								$fila=$consulta2->fetch_assoc();

								$totalprecios=$fila['TotalPrecios'];
								$iva=($totalprecios*19)/100;

								echo "$iva";
							?>
							</center>
						</td>
						
					</tr>
					<tr>
						<td colspan="4">
							<center><strong>Total: </strong></center>
						</td>
						<td colspan="2">
							<center>
							<?php 
								require("../../conectar.php");
								$sql2="SELECT SUM(subtotal) as TotalPrecios FROM pedido";
								$consulta2=$conexion->query($sql2);
								$fila=$consulta2->fetch_assoc();

								$totalprecios=$fila['TotalPrecios'];
								$iva=($totalprecios*19)/100;
								$total2=$totalprecios+$iva;

								echo "<strong>$total2</strong>";
							?>
							</center>
						</td>
					</tr>
				</tbody>
		</table></center>

<center>
	<div class="jumbotron boxcob">
	<form action="cobrar-factura.php" method="GET" accept-charset="utf-8">
		Indique el valor con el que se paga:
		<input type="text" name="valor_pagar" required=""><br>
		Fecha:
		<input type="date" name="fecha" required=""><br><br>
		<input type="submit" class="btn-lg btn-default"name="ingresar" value="Ingresar">
	</form>
	</div>
</center>

<center>
	<div class="container"> 
		<a href="#cobrar" class="btn btn-primary btn-lg" data-toggle="modal"> Cobrar </a><br><br>
			<div class="modal fade" id="cobrar">
				<div class="modal-dialog">
					<div class="modal-content">
						<div class="modal-header">
							<button tyle="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
							<h3 class="modal-title"><strong>Total factura</strong></h3>
						</div>
						<div class="modal-body">
							<table border="1px">
								<tbody>
								<tr>
									<td>Dato</td>
									<td>Valor</td>
								</tr>
								<tr>
									<td>Fecha</td>
									<td><?php
										require("../../conectar.php");
										$sql3='SELECT * FROM cobro';
										$consulta3=$conexion->query($sql3);
										$mostrar3=$consulta3->fetch_assoc();
										$dia2=$mostrar3['dia'];
										$mes2=$mostrar3['mes'];
										$año2=$mostrar3['ano'];
								 		echo "$dia2","-","$mes2","-","$año2";	
								 	?></td>
								</tr>
								<tr>
									<td>Paga</td>
									<td><?php 
										require("../../conectar.php");
										$sql3='SELECT * FROM cobro';
										$consulta3=$conexion->query($sql3);
								 		while ($mostrar3=$consulta3->fetch_assoc()){
								 		echo $mostrar3['paga'];}
								 	?></td>
								</tr>
								<tr>
									<td>Monto</td>
									<td><?php 
										require("../../conectar.php");
										$sql3='SELECT * FROM cobro';
										$consulta3=$conexion->query($sql3);
										while ($mostrar3=$consulta3->fetch_assoc()){
										echo $mostrar3['monto'];}														 
									?></td>
								</tr>
								<tr>
									<td>Iva</td>
									<td><?php 
										require("../../conectar.php");
										$sql3='SELECT * FROM cobro';
										$consulta3=$conexion->query($sql3);
								 		while ($mostrar3=$consulta3->fetch_assoc()){
								 		echo $mostrar3['iva'];}
								 	?></td>
								</tr>
								<tr>
									<td>Total</td>
									<td><?php 
										require("../../conectar.php");
										$sql3='SELECT * FROM cobro';
										$consulta3=$conexion->query($sql3);
								 		while ($mostrar3=$consulta3->fetch_assoc()){
								 		echo $mostrar3['total'];}														 
								 	?></td>
								</tr>
								<tr>
									<td>Cambio</td>
									<td><?php 
										require("../../conectar.php");
										$sql3='SELECT * FROM cobro';
										$consulta3=$conexion->query($sql3);
								 		while ($mostrar3=$consulta3->fetch_assoc()){
								 		echo $mostrar3['cambio'];}
									?></td>
								</tr>
								</tbody>
							</table>
						</div>				
						<div class="modal-footer">
							<center>
							<form action="terminar.php" method="post" accept-charset="utf-8">
								<input type="submit" value="Terminar" class="btn btn-primary btn-lg">
							</form>
							</center>
						</div>	
					</div>
				</div>
			</div>
		</div>
								
	<script src="http://code.jquery.com/jquery-latest.js"></script>
	<script src="../../assets/js/bootstrap.min.js"></script>
</center>


</body>
</html>