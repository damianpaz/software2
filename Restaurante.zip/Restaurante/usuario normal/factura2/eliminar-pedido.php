<?php
require("../../conectar.php");

$id=$_REQUEST['id'];


$eliminar="DELETE FROM pedido WHERE id='$id' ";	
$resultado=mysqli_query($conexion,$eliminar);

if ($resultado) {
	header("location: factura.php");
}else {
	echo "Error en la modificacion";
}

?>