<!DOCTYPE html>
<html>
<head>
	<title>agregar</title>
</head>

<body>

<?php 
			
			require("../../conectar.php");

			$id_solicitar=$_GET['id-menu'];
			$cantidad=$_GET['cantidad'];

			$traer_id="SELECT * FROM menu WHERE ID='$id_solicitar'";
			$consulta=$conexion->query($traer_id);
			$mostrar=$consulta->fetch_assoc();
	
			$id_mostrar= $mostrar['ID'];
			$nombre_mostrar= $mostrar['nombre'];
			$precio_mostrar= $mostrar['precio'];
			$sub= ($mostrar['precio'] * $cantidad);
			

					$guardar="INSERT INTO pedido (ID,nombre,precio,cantidad,subtotal) VALUES ('$id_mostrar','$nombre_mostrar','$precio_mostrar','$cantidad' , '$sub')";
					$res=mysqli_query($conexion,$guardar);

			echo "<script>window.location.assign('factura.php') </script>";
?>	



</body>
</html>

	
