<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <title>Prueba alerta</title>
        <link rel="stylesheet" type="text/css" href="../../assets/SweetAlert2/sweetalert2.css">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    </head>
    <body>
    	

       <script>
       		
		swal("ERROR","El valor a pagar es mayor que el pago","error", {
			  buttons: {
			    Ok: true,
			  },
			})
			.then((value) => {
			  switch (value) {
			 
			    case "Ok":
			      window.location='factura.php';
			      break;
			 
			  }
			});
       		
		</script>

    </body>
</html>