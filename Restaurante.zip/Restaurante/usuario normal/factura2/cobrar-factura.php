<?php

$valor_pagar=$_GET['valor_pagar'];
$fecha= strtotime($_GET['fecha']);
$dia = strftime("%d",$fecha);
$mes = strftime("%m",$fecha);
$ano = strftime("%Y",$fecha);

require("../../conectar.php");

	$sql2="SELECT SUM(subtotal) as TotalPrecios FROM pedido";
	$consulta2=$conexion->query($sql2);
    $fila=$consulta2->fetch_assoc();
	$totalprecios=$fila['TotalPrecios'];

	$iva=($totalprecios*19)/100;
	$total= $totalprecios+$iva;

if ($valor_pagar < $total || empty($total)) {
	echo "<script>window.location.assign('error-paga.php') </script>";
}else{
	$cambio= $valor_pagar - $total;

	$revisar="SELECT * FROM cobro";
	$cons=$conexion->query($revisar);
	$traer=$cons->fetch_assoc();
	
	if (empty($traer['paga'])) {

		$guardar="INSERT INTO cobro (dia,mes,ano,paga,monto,iva,total,cambio) VALUES ('$dia','$mes','$ano','$valor_pagar','$totalprecios','$iva','$total' , '$cambio')";
		$res=mysqli_query($conexion,$guardar);
		echo "<script>window.location.assign('factura.php') </script>";
	
	}else{
		echo "<script>window.location.assign('factura.php') </script>";
	}
	
	
}




?>







