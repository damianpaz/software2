
<!DOCTYPE html>
<html>
<head>
	<title>Menu Restaurante</title>
	<meta name="viewport" content="width=device-width, initial-escale=1.0">
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../../assets/css/tabla-menu.css">
</head>
<body>
<body >
<center><table>
	<thead>
		<tr>
			<th colspan="5"><br><h1><center>MENU REST. GRAN SAZON</center><br></h1></th>
		</tr>
		<tr>
			<br>
			<td><center><br><b>ID</center></td>
			<td><center><br><b>NOMBRE</center></td>
			<td><center><br><b>PRECIO</center></td>
			<td><center><br><b>TIPO</center></td>
			<td><center><br><b>DESCRIPCION</center></td>
		</tr>
		</thead>
		<tbody>	
		
		<?php
		require("conectar.php");
		$sql='SELECT * FROM menu';
		$consulta=$conexion->query($sql);
 		while ($mostrar=$consulta->fetch_assoc()) {
		

		echo '<tr>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['ID'];
		echo "</center>";
		echo '</td>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['nombre'];
		echo "</center>"; 
		echo '</td>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['precio'];
		echo "</center>";
		echo '</td>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['tipo'];
		echo "</center>"; 
		echo '</td>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['descripcion'];
		echo "</center>";
		echo '</td>';
		echo '</tr>';	
		}
		?>
	</tbody>
	</table>
	<center><a href="../index2.php"><img src="../../Images/boton-salir.png" width="180px" height="80px"></a></center>
	<br>

</body>
</html>