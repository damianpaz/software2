<?php
require("../conectar.php");

$id=$_REQUEST['id'];
$usuario=$_POST['usuario'];
$nombre=$_POST['nombres'];
$apellido=$_POST['apellidos'];
$clave=$_POST['clave'];
$correo=$_POST['correo'];
$cargo=$_POST['Cargo'];

$modificar="UPDATE usuarios SET usuario='$usuario', nombres='$nombre', apellidos='$apellido' ,clave='$clave' , correo='$correo' , Cargo='$cargo' WHERE id='$id' ";	
$resultado=mysqli_query($conexion,$modificar);

if ($resultado) {	
header("location: usuarios.php");
}else{
	echo "Error en la modificacion";
	echo 'header("location: usuarios.php");';
}