
<html lang="es">
	<head>
		<title>Modificar Usuario</title>
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/style2.css">
	</head>
	<body>
		<?php

		$id=$_REQUEST['id'];
		require("../conectar.php");
		$sql="SELECT * FROM usuarios WHERE ID='$id'";
		$consulta=$conexion->query($sql);
 		$mostrar=$consulta->fetch_assoc();
 		?>

			<div class="jumbotron boxlogin">
			<h2><center>Modificar</center></h2>
					
			<form action="modificar-usuario-proceso.php?id=<?php echo $mostrar['ID'];?>" method="post">
			<br>
			<label>Usuario </label>
			<input type="text" name="usuario"  class="form-control" required="" value="<?php echo $mostrar['usuario']; ?>">
			<label>Nombres </label>
			<input type="text" name="nombres"  class="form-control" required="" value="<?php echo $mostrar['nombres']; ?>">
			<label>Apellidos </label>
			<input type="text" name="apellidos"  class="form-control" required="" value="<?php echo $mostrar['apellidos']; ?>">
			<br>
			<label>Contraseña </label>
			<input type="password" name="clave" class="form-control" required="" value="<?php echo $mostrar['clave'];?>">
			<br>
			<label>Correo </label>
			<input type="text" name="correo" class="form-control" required="" value="<?php echo $mostrar['correo']; ?>">
			<br>
			<label>Cargo </label>
			<input type="text" name="Cargo" class="form-control"  value="<?php echo $mostrar['Cargo']; ?>">
			<br><center>
			<input type="submit" class="btn btn-primary" name="Reemplazar" value="Reemplazar"></center>	
			<br><center>
			<input type="button" class="btn btn-success" value="Volver" onClick='document.location.href="usuarios.php"'></center>
			</form>
		
		</div>
		
	</body>
</html>