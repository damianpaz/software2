<html lang="es">
	<head>
		<title>Agregar Usuario</title>
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/style2.css">
	</head>
	<body>

		<?php

				require("../conectar.php");

				$usuario=$_POST['usuario'];
				$nombre=$_POST['nombres'];
				$apellido=$_POST['apellidos'];
				$clave=$_POST['clave'];
				$correo=$_POST['correo'];
				$cargo=$_POST['Cargo'];

				if ($usuario=="" && $clave=="") {
					echo "Usuario no agregado, por favor rellene campos requeridos correctamente";
					echo '<a title="Salir" href="usuario-nuevo.php"><img src="../Images/icono-volver.png" width="200px" height="100px"></a>';
				}else{		
					$agregar="INSERT INTO usuarios (usuario,nombres,apellidos,clave,correo,Cargo) VALUES ('$usuario','$nombre', '$apellido','$clave','$correo','$cargo')";	
					$resultado=mysqli_query($conexion,$agregar);

						if ($resultado) {
							?>
							<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
					        <script type="text/javascript">
					       	  swal({
									  position: 'top-end',
									  type: 'success',
									  title: 'Usuario agregado',
									  showConfirmButton: false,
									  timer: 2000
									}) 
							  window.location='usuarios.php'; 
							</script>					        

					<?php
						
					} else {
						?>
							<script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
					        <script type="text/javascript">
					       	  swal({
									  position: 'top-end',
									  type: 'error',
									  title: 'Error! Falla al crear usuario',
									  showConfirmButton: false,
									  timer: 2000
									}) 
							  window.location='usuarios.php'; 
							</script>
				<?php
					}
				};

				?>	
	</body>
</html>