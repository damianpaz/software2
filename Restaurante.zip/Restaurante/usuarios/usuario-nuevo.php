
<html lang="es">
	<head>
		<title>Formulario Agregar Usuario</title>
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/style2.css">
	</head>
	<body>
		
			<div class="jumbotron boxlogin">
			<h2><center>Sign Up</center></h2>
					
			<form action="agregar-usuario.php" method="post">
			<br>
			<label>Usuario </label>
			<input type="text" placeholder="Usuario" name="usuario"  class="form-control" required="">
			<br>
			<label>Nombres </label>
			<input type="text" placeholder="Nombre" name="nombres"  class="form-control" required="">
			<br>
			<label>Apellidos </label>
			<input type="text" placeholder="Apellido" name="apellidos"  class="form-control" required="">
			<br>
			<label>Contraseña </label>
			<input type="password" placeholder="Contraseña" name="clave" class="form-control" required="">
			<br>
			<label>Correo </label>
			<input type="text" placeholder="Email" name="correo" class="form-control" required="">
			<br>
			<label>Cargo </label>
			<input type="text" placeholder="Cargo" name="Cargo" class="form-control" >

			<!-- Botones -->
			
			<br><center>
			<input type="submit" class="btn btn-primary" name="Enviar"></center>			
			<br><center>
			<input type="button" class="btn btn-success" value="Volver" onClick='document.location.href="usuarios.php"'></center>
			</form>
		
		</div>
		
	</body>
</html>