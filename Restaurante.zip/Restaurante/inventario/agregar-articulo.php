<html lang="es">
	<head>
		<title>Agregar Usuario</title>
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/style2.css">
	</head>
	<body>

		<?php

				require("conectar.php");

				$articulo=$_POST['articulo'];
				$tipo=$_POST['tipo'];
				$cantidad=$_POST['cantidad'];
				
				if ($articulo=="" && $cantidad=="") {
					echo "Usuario no agregado, por favor rellene campos requeridos correctamente";
					echo '<a title="Salir" href="inventario.php"><img src="../Images/icono-volver.png" width="200px" height="100px"></a>';
				}else{		
					$agregar="INSERT INTO inventario (articulo,tipo,cantidad) VALUES ('$articulo','$tipo','$cantidad')";	
					$resultado=mysqli_query($conexion,$agregar);

						if ($resultado) {
							header("location: inventario.php");
					
					} else {
						echo "<br>";
						echo "Error, articulo no agregado";	
					}
				}

		?>	
	</body>
</html>