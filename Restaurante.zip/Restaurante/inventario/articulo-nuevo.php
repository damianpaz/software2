
<html lang="es">
	<head>
		<title>Agregar Articulo</title>
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/style2.css">
	</head>
	<body>
		
			<div class="jumbotron boxlogin">
			<h2><center>Articulo Nuevo</center></h2>
					
			<form action="agregar-articulo.php" method="post">
			<br>
			<label>Articulo </label>
			<input type="text" placeholder="Nombre" name="articulo"  class="form-control" required="">
			<br>
			<label>Tipo </label>
			<input type="text" placeholder="Tipo" name="tipo" class="form-control" required="">
			<br>
			<label>Cantidad </label>
			<input type="text" placeholder="#" name="cantidad" class="form-control" required="">
			
			<br><center>
			<input type="submit" class="btn btn-primary" name="Enviar"></center>			
			<br><center>
			<input type="button" class="btn btn-success" value="Volver" onClick='document.location.href="inventario.php"'></center>
			</form>
		
		</div>
		
	</body>
</html>