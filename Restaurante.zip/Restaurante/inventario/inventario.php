
<!DOCTYPE html>
<html>
<head>
	<title>Inventario Restaurante</title>
	<meta name="viewport" content="width=device-width, initial-escale=1.0">
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/tabla-inventario.css">
</head>
<body>
<body >
<center><table>
	<thead>
		<tr>
			<th colspan="5"><br><h1><center>INVENTARIO GRAN SAZON</center><br></h1></th>
			<th><center><input type="button" class="btn btn-success" value="Nuevo" onClick='document.location.href="articulo-nuevo.php"'></center>
			</th>
		</tr>
		<tr>
			<br>
			<td><center><br><b>ID</center></td>
			<td><center><br><b>ARTICULO</center></td>
			<td><center><br><b>TIPO</center></td>
			<td><center><br><b>CANTIDAD</center></td>
			<td colspan="2"><center><br><b>OPERACIONES</center></td>
		</tr>
		</thead>
		<tbody>	
		
		<?php
		require("conectar.php");
		$sql='SELECT * FROM inventario';
		$consulta=$conexion->query($sql);
 		while ($mostrar=$consulta->fetch_assoc()) {
		

		echo '<tr>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['ID'];
		echo "</center>";
		echo '</td>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['articulo']; 
		echo "</center>";
		echo '</td>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['tipo'];
		echo "</center>";
		echo '</td>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['cantidad'];
		echo "</center>";
		echo '</td>';
		?>

		<td><a href="eliminar-articulo.php?id=<?php echo $mostrar['ID'];?>"><center>Eliminar</center></a></td>
		<td><a href="modificar-articulo.php?id=<?php echo $mostrar['ID'];?>"><center>Modificar</center></a></td>

		<?php
		echo '</tr>';	
		}
		?>
	</tbody>
	</table>
	<center><a href="../index.php"><img src="../Images/boton-salir.png" width="180px" height="80px"></a></center>
	<br>

</body>
</html>