<?php
require("conectar.php");

$id=$_REQUEST['id'];
$articulo=$_POST['articulo'];
$tipo=$_POST['tipo'];
$cantidad=$_POST['cantidad'];


$modificar="UPDATE inventario SET articulo='$articulo', tipo='$tipo' , cantidad='$cantidad' WHERE id ='$id' ";	
$resultado=mysqli_query($conexion,$modificar);

if ($resultado) {
	header("location: inventario.php");
}else {
	echo "Error en la modificacion";
}