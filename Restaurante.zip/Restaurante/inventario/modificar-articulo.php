
<html lang="es">
	<head>
		<title>Modificar Articulo</title>
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="../bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/css/style2.css">
	</head>
	<body>
		<?php

		$id=$_REQUEST['id'];
		require("conectar.php");
		$sql="SELECT * FROM inventario WHERE ID='$id'";
		$consulta=$conexion->query($sql);
 		$mostrar=$consulta->fetch_assoc();
 		?> 

			<div class="jumbotron boxlogin">
			<h2><center>Modificar</center></h2>
					
			<form action="modificar-articulo-proceso.php?id=<?php echo $mostrar['ID'];?>" method="post">
			<br>
			<label>Articulo </label>
			<input type="text" placeholder="Articulo" name="articulo"  class="form-control" required="" value="<?php echo $mostrar['articulo']; ?>">
			<br>
			<label>Tipo </label>
			<input type="text" placeholder="Tipo" name="tipo" class="form-control" required="" value="<?php echo $mostrar['tipo'];?>">
			<br>
			<label>Cantidad </label>
			<input type="text" placeholder="Cantidad" name="cantidad" class="form-control" required="" value="<?php echo $mostrar['cantidad']; ?>">
			<br><center>
			<input type="submit" class="btn btn-primary" name="Modificar" value="Modificar"></center>
			<br><center>
			<input type="button" class="btn btn-success" value="Volver" onClick='document.location.href="inventario.php"'></center>			
			</form>
		
		</div>
		
	</body>
</html>