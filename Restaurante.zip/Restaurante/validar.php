
<?php

	$usuario=$_POST['usuario'];
	$clave=$_POST['clave'];

require("conectar.php");

$consulta="SELECT * FROM usuarios WHERE usuario='$usuario' and clave='$clave'";
$resultado=mysqli_query($conexion,$consulta);

$filas= mysqli_num_rows($resultado);
if ($filas>0) {
	if ($usuario == 'Administrador' || $usuario=="Soporte") {
		header("location: index.php");
	}else{
		header("location: usuario normal/index2.php");
	}	
} else {

	header("location: login-error.php");
}

mysqli_free_result($resultado);
mysqli_close($conexion);



