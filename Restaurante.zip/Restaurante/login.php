<html lang="es">
	<head>
		<title>Formulario de Login</title>
		<meta name="viewport" content="width=device-width, initial-escale=1.0">
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="assets/css/login.css">
		<link rel="stylesheet" type="text/css" href="../assets/SweetAlert2/sweetalert2.css">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

	</head>
	<body>
		<div class="jumbotron boxlogin">

			<h2><center>Login</center></h2>
			
		
			<form action="validar.php" method="post">
			<br>
			<label>Usuario </label>
			<input type="text" placeholder="Usuario" name="usuario"  class="form-control" required="">
			<br>
			<label>Contraseña </label>
			<input type="password" placeholder="Contraseña" name="clave" class="form-control" required="">
			<br><center>
			<input type="submit" class="btn btn-primary" name="Ingresar"></center>
		</form>
		</div>	
		
	</body>
</html>
