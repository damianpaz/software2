<?php
if (isset($_POST['consulta'])) {		
		$mes = $_POST['lmes'];
		$año = $_POST['ano'];

	require("../../conectar.php");
	$sql="SELECT SUM(venta) as TotalVen FROM ventas WHERE fmes='$mes' && fano='$año'";
	$consulta=$conexion->query($sql);
	$fila=$consulta->fetch_assoc();
	$totalventa= $fila['TotalVen'];
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
	<title>Consulta por Mes</title>
	<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../assets/SweetAlert2/sweetalert2.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../assets/css/consultas2.css">
</head>
<body>
	<div class="jumbotron boxcons">

			<h2><center>Indica el mes que buscas: </center></h2>
			
		
			<form action="consulta-mes.php" method="post">
			<br>
			<center><label>Mes</label></center><br>
			<center>
						
			<select name="lmes" size="1" required >
				<option value="">Selecciona</option>
				<option value="1">Enero</option>
				<option value="2">Febrero</option>
				<option value="3">Marzo</option>
				<option value="4">Abril</option>
				<option value="5">Mayo</option>
				<option value="6">Junio</option>
				<option value="7">Julio</option>
				<option value="8">Agosto</option>
				<option value="9">Septiembre</option>
				<option value="10">Octubre</option>
				<option value="11">Noviembre</option>
				<option value="12">Diciembre</option>
			</select>		
			</center>
			<br>
			<center><label>Año</label></center><br>
			<center><input type="text" name="ano" placeholder="AAAA" required ></center><br>	

			<center><input type="submit" class="btn btn-primary" value="Consultar" 	name="consulta"></center>
		</form>
		</div>

		<br>

		<center><table border="1">
				<thead>
					<tr>
						<th colspan="3"><center><h4><b>Resultado</h4></center></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><center><b>Mes</center></td>
						<td><center><b>Año</center></td>
						<td><center><b>Valor en Pesos<center></td>
					</tr>
					<tr>
						<td><center>
							<?php  
							if (isset($_POST['consulta'])) {
							switch ($mes) {
							    case 0:
							        echo "No existe";
							        break;
							    case 1:
							        echo "Enero";
							        break;
							    case 2:
							        echo "Febrero";
							        break;
							    case 3:
							        echo "Marzo";
							        break;
							    case 4:
							        echo "Abril";
							        break;
							    case 5:
							        echo "Mayo";
							        break;
							    case 6:
							        echo "Junio";
							        break;
							    case 7:
							        echo "Julio";
							        break;
							    case 8:
							        echo "Agosto";
							        break;
							    case 9:
							        echo "Septiembre";
							        break;
							    case 10:
							        echo "Octubre";
							        break;
							    case 11:
							        echo "Noviembre";
							        break;
							    case 12:
							        echo "Diciembre";
							        break;
									}
								}
							?>
							</center>
						</td>
						<td><center>
							<?php  
							if (isset($_POST['consulta'])) {
								echo "$año";
								}
							?>
							</center>
						</td>
						<td><center>
							<?php  
							if (isset($_POST['consulta'])) {
								if ($totalventa == 0) {
									echo "Esta fecha no cuenta con ninguna venta";
								}else{
								echo "$totalventa";
								}
							}
							?></center>
						</td>
					</tr>
				</tbody>
			</table>
			</center>			
		

		<center>
		<input type="button" value="Salir" class="btn btn-warning btn-lg" onclick="Eventosalir()" />

       <script>
       		function Eventosalir(){
		swal("¿Seguro que desea Salir?","", {
			  buttons: {
			    cancel: "Cancelar",
			    Salir: true,
			  },
			})
			.then((value) => {
			  switch (value) {
			 
			    case "Salir":
			    		window.location='medida-total.php';
			      break;
			 
			    default:
			      swal("Cancelado","","error");
			  }
			});
       		}
		</script>
	</center>

</body>
</html>