<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
	<title>Ventas restaurante</title>
	<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../assets/SweetAlert2/sweetalert2.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../assets/css/ventas.css">

</head>
<body>


<center><table>
	<thead>
		<tr>
			<th colspan="2"><br><h2><center>VENTAS RESTAURANTE</center><br></h2></th>
			<th>
			<center>

	<a href="#consulta" class="btn btn-primary btn-lg" data-toggle="modal"> Consultar </a>		
		<div class="modal fade" id="consulta">
			<div class="modal-dialog">
				<div class="modal-content">
				<!-- Header -->
				<div class="modal-header" 	color="#D0ECE7">
					<button tyle="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
					<h3 class="modal-title"><strong>Consultar</strong></h3>
				</div>
				<div class="modal-body">
				<input type="button" class="btn btn-primary btn-lg" value="Por Dia" onClick='document.location.href="consulta-dia.php"' />
				<input type="button" class="btn btn-success btn-lg" value="Por Mes" onClick='document.location.href="consulta-mes.php"' />
				<input type="button" class="btn btn-info btn-lg" value="Por Año" onClick='document.location.href="consulta-año.php"' />
				</div>
				</div>
			</div>
		</div>
										
		<script src="http://code.jquery.com/jquery-latest.js"></script>
		<script src="../../assets/js/bootstrap.min.js"></script>
		</center>

		</th>
		</tr>
		<tr>
			<br>
			<td><center><br><b>ID</center></td>
			<td><center><br><b>FECHA DE VENTA</center></td>
			<td><center><br><b>VALOR VENTA</center></td>
		</tr>
		</thead>
		<tbody>	
		
		<?php
		require("../../conectar.php");
		$sql='SELECT * FROM ventas';
		$consulta=$conexion->query($sql);
 		while ($mostrar=$consulta->fetch_assoc()) {
		$dia=$mostrar['fdia'];
		$mes=$mostrar['fmes'];
		$ano=$mostrar['fano'];

		echo '<tr>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['ID'];
		echo "</center>";
		echo '</td>';
		echo '<td>';
		echo "<center>";
		echo "$dia","/","$mes","/","$ano"; 
		echo "</center>";
		echo '</td>';
		echo '<td>';
		echo "<center>";
		echo $mostrar['venta'];
		echo "</center>";
		echo '</td>';
		echo '</tr>';	
		}
		?>

		<tr>
			<th colspan="2" ><center> Total Ventas: </center></th>
			<?php
				require("../../conectar.php");
			$sql2="SELECT SUM(venta) as TotalVenta FROM ventas";
			$consulta2=$conexion->query($sql2);
    		$fila=$consulta2->fetch_assoc();
			$totalventas=$fila['TotalVenta'];
			echo '<td bgcolor="#EC7063">';
			echo "<center>","<strong>";
			echo "$totalventas";
			echo "</strong>","</center>";
			echo '</td>';
			?>
		</tr>
	</tbody>
	</table>

	<br>
	<center><a href="../../index.php"><img src="../../Images/boton-salir.png" width="180px" height="80px"></a></center>
	<br>


</body>
</html>