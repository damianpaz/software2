<?php
if (isset($_POST['consulta'])) {
		$fecha= strtotime($_POST['fecha']);

		$dia = strftime("%d",$fecha);
		$mes = strftime("%m",$fecha);
		$año = strftime("%Y",$fecha);


	require("../../conectar.php");
	$sql="SELECT SUM(venta) as TotalVen FROM ventas WHERE fdia='$dia' && fmes='$mes' && fano='$año'";
	$consulta=$conexion->query($sql);
	$fila=$consulta->fetch_assoc();
	$totalventa= $fila['TotalVen'];
	

}


?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
	<title>Consulta por dia</title>
	<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../assets/SweetAlert2/sweetalert2.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../assets/css/consultas.css">
</head>
<body>
	<div class="jumbotron boxcons">

			<h2><center>Indica el dia: </center></h2>
			
		
			<form action="consulta-dia.php" method="post">
			<br>
			<center><label>Fecha</label></center>
			<center><input type="date" name="fecha" required=""></center>
			<br>			
			<center><input type="submit" class="btn btn-primary" value="Consultar "name="consulta" href="#consulta"data-toggle="modal"></center>
		</form>
		</div>

<br>
		<center>
				<center><table border="1">
				<thead>
					<tr>
						<th colspan="2"><center><h4><strong>Resultado</strong></h4></center></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><center><b>Fecha</center></td>
						<td><center><b>Valor en Pesos<center></td>
					</tr>
					<tr>
						<td><center>
							<?php  
							if (isset($_POST['consulta'])) {
								echo "$dia/$mes/$año";
								}
							?>
							</center>
						</td>
						<td><center>
							<?php  
							if (isset($_POST['consulta'])) {
								if ($totalventa == 0) {
									echo "Esta fecha no cuenta con ninguna venta";
								}else{
								echo "$totalventa";
								}
							}
							?></center>
						</td>
					</tr>
				</tbody>
			</table>
			</center>			

		</center>

		<center>
		<input type="button" value="Salir" class="btn btn-warning btn-lg" onclick="Eventosalir()" />

       <script>
       		function Eventosalir(){
		swal("¿Seguro que desea Salir?","", {
			  buttons: {
			    cancel: "Cancelar",
			    Salir: true,
			  },
			})
			.then((value) => {
			  switch (value) {
			 
			    case "Salir":
			    		window.location='medida-total.php';
			      break;
			 
			    default:
			      swal("Cancelado","","error");
			  }
			});
       		}
		</script>
	</center>

</body>
</html>