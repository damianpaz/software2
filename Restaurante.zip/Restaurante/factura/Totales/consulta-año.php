<?php
if (isset($_POST['consulta'])) {		
	
		$año = $_POST['ano'];

	require("../../conectar.php");
	$sql="SELECT SUM(venta) as TotalVen FROM ventas WHERE fano='$año'";
	$consulta=$conexion->query($sql);
	$fila=$consulta->fetch_assoc();
	$totalventa= $fila['TotalVen'];
}
?>

<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="Content type" content="text/html; charset=utf-8">
	<meta name="viewport" content="width=device-width, user-scalable=no, initial-scale=1.0">
	<title>Consulta por año</title>
	<link rel="stylesheet" type="text/css" href="../../assets/css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="../../assets/SweetAlert2/sweetalert2.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <link rel="stylesheet" type="text/css" href="../../assets/css/consultas2.css">
</head>
<body>
	<div class="jumbotron boxcons">

			<h2><center>Indica el Año: </center></h2>
			
		
			<form action="consulta-año.php" method="post">
			<br>
			<center><label>Año</label></center><br>
			<center><input type="text" name="ano" placeholder="AAAA" required ></center><br>
			<center><input type="submit" class="btn btn-primary" value="Consultar" 	name="consulta" required=""></center>
		</form>
		</div>

		<center><table border="1">
				<thead>
					<tr>
						<th colspan="2"><center><h4><b>Resultado</h4></center></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><center><b>Año</center></td>
						<td><center><b>Valor en Pesos<center></td>
					</tr>
					<tr>
						<td><center>
							<?php  
							if (isset($_POST['consulta'])) {
								echo "$año";
								}
							?>
							</center>
						</td>
						<td><center>
							<?php  
							if (isset($_POST['consulta'])) {
								if ($totalventa == 0) {
									echo "Esta fecha no cuenta con ninguna venta";
								}else{
								echo "$totalventa";
								}
							}
							?></center>
						</td>
					</tr>
				</tbody>
			</table>
			</center>			


		<center>
		<input type="button" value="Salir" class="btn btn-warning btn-lg" onclick="Eventosalir()" />

       <script>
       		function Eventosalir(){
		swal("¿Seguro que desea Salir?","", {
			  buttons: {
			    cancel: "Cancelar",
			    Salir: true,
			  },
			})
			.then((value) => {
			  switch (value) {
			 
			    case "Salir":
			    		window.location='medida-total.php';
			      break;
			 
			    default:
			      swal("Cancelado","","error");
			  }
			});
       		}
		</script>
	</center>

</body>
</html>