<?php

if (isset($_POST['consul'])) {

		$fecha= strtotime($_POST['fecha']);//tu variable
		$dia = strftime("%d",$fecha).strftime("%m",$fecha);
		$mes = strftime("%m",$fecha);
		$año = strftime("%Y",$fecha);

echo "$dia","<br>";
echo "$mes","<br>";
echo "$año","<br>";



}

	
	//require("../../conectar.php");
	//$sql="SELECT SUM(venta) as TotalVen FROM ventas WHERE fecha='$fecha'";
	//$consulta=$conexion->query($sql);
	//$fila=$consulta->fetch_assoc();
	//$totalventa= $fila['TotalVen'];

//echo "$totalventa";


?>

<!DOCTYPE html>
<html>
<head>
	<title>consulta</title>
</head>
<body>

	<div>
		<form action="consultar-venta.php" method="POST">
			Fecha:
			<input type="date" name="fecha">
						
			<input type="submit" name="consul">

		</form>	
	</div>

</body>
</html>