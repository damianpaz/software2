<?php

require("../conectar.php");

$sql3='SELECT * FROM cobro';
	$consulta3=$conexion->query($sql3);
	$mostrar3=$consulta3->fetch_assoc();
	$dia= $mostrar3['dia'];
	$mes= $mostrar3['mes'];
	$año= $mostrar3['ano'];


$sql2="SELECT SUM(subtotal) as TotalPrecios FROM pedido";
	$consulta2=$conexion->query($sql2);
	$fila=$consulta2->fetch_assoc();
	$totalprecios=$fila['TotalPrecios'];
 	$iva=($totalprecios*19)/100;
	$total2=$totalprecios+$iva;


$guardar_venta="INSERT INTO ventas (fdia,fmes,fano,venta) VALUES ('$dia','$mes','$año','$total2')";
	$res=mysqli_query($conexion,$guardar_venta);


$eliminart= "DELETE FROM pedido WHERE ID";
$accion=$conexion->query($eliminart);

$eliminart2= "DELETE FROM cobro WHERE ID";
$accion2=$conexion->query($eliminart2);

echo "<script>window.location.assign('factura.php') </script>";