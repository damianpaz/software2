<!DOCTYPE html>
<html>
<head>
	<title>Error Autenticacion</title>
		<meta name="viewport" content="width=device-width, initial-escale=1.0">
		<meta http-equiv="Content type" content="text/html; charset=utf-8">
		<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
		<link rel="stylesheet" type="text/css" href="../assets/SweetAlert2/sweetalert2.css">
        <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
		<link rel="stylesheet" type="text/css" href="assets/css/login.css">
</head>
<body>


	<script>
			swal("Error!","Ingrese usuario y constraseña validos", "error" ,{
			  buttons: {
			  	OK: true,
				},
				})
				.then((value) => {
				  switch (value) {
				    case "OK":
				    	window.location='login.php';
					 	break;
					}
					});
				    
	</script>
	
	</body>
	</html>



