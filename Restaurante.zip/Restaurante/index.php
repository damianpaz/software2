<html>
<head>  

<title>Inicio</title>
<meta name="viewport" content="width=device-width, initial-escale=1.0">
<meta http-equiv="Content type" content="text/html; charset=utf-8">
<link rel="stylesheet" type="text/css" href="bootstrap/css/bootstrap.css">
<link rel="stylesheet" type="text/css" href="assets/SweetAlert2/sweetalert2.css">
 <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
<link rel="stylesheet" type="text/css" href="assets/css/style.css"> 
 
</head>


<body  >

<div id="header">
	<div class="col text-right">
		<input type="button" value="Cerrar Sesion" class="btn btn-primary btn-lg" onclick="Eventosalir()" />
				       <script>
				       		function Eventosalir(){

						swal("¿Seguro que desea Cerrar sesion?","", {
							  buttons: {
							    cancel: "Cancelar",
							    Salir: true,
							  },
							})
							.then((value) => {
							  switch (value) {
							 
							    case "Salir":
							    		window.location='login.php';
							      break;
							 
							    default:
							      swal("Cancelado","","error");
							  }
							});
				       		}
						</script>

	</div>	
</div>


	<center><table border="0" width="95%" height="500px">
		<thead>
			<tr>
			<th colspan="5"width="95%" height="100px"><h1><center><font color="#5D6D7E" face="Maiandra GD">RESTAURANTE EL GRAN SAZON</face></font></center></h1></th>
			</tr>
		</thead>
		<tbody>		
			<tr>
			<br><br>
			<td><center><a title="Inventario" href="inventario/inventario.php"><img src="Images/inven.jpg" alt="Inventario" width="200px" height="200px"></a><br><br><b>INVENTARIO</center></td>
			<td><center><a title="Pedido" href="factura/factura.php"><img src="Images/icono-factura.png" width="200px" height="200px"></a><br><br><b>PEDIDO</center></td>
			<td><center><a title="Menu" href="menu/menu.php"><img src="Images/icono-menu.png" width="200px" height="200px"></a><br><br><b>MENU</center></td>
			<td><center><a title="Usuarios" href="usuarios/usuarios.php"><img src="Images/icono-usuarios.png" width="200px" height="200px"></a><br><br><b>USUARIOS</center></td>
			<td><center><a title="Ventas" href="factura/Totales/medida-total.php"><img src="Images/icono-ventas.jpg" width="200px" height="200px"></a><br><br><b>VENTAS</center></td>
		</tr>
		</tbody>
		</table>
		</center>	


<div id="footer">

<center>
<br><h5><font color="#FBFCFC" face="Comic Sans MS">Copyright 2018 Quejas o Inquietudes via email a
<a href="mailto:ivan.gachancipag@campusucc.edu.co">Ivan Gachancipa</a> o <a href="mailto:damian.paz@campusucc.edu.co"> Damian Paz
</a></font></h5>
</center>
	
</div>
</body>
</html>

